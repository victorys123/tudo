let andar = 5;

let subindo = false;

while (andar !==0){
    alert(`Espera mais um pouquinho. Andar Atual: ${andar}`);
    andar--;
}

alert ("Poder sair te ta tudo tranquilo");